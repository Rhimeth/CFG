#ifndef VISUALIZER_H
#define VISUALIZER_H

#include "graph_generator.h"
#include <string>

namespace Visualizer {

bool exportToDot(const GraphGenerator::CFGGraph* graph, const std::string& filename);
std::string generateDotRepresentation(const GraphGenerator::CFGGraph* graph);

}

#endif // VISUALIZER_H