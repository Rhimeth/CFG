#ifndef GRAPHWIDGET_H
#define GRAPHWIDGET_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QMap>
#include <QJsonObject>
#include <QJsonArray>

class Edge;
class CFGNode;
class GraphicalCFGNode;

class GraphWidget : public QGraphicsView {
    Q_OBJECT

public:
    explicit GraphWidget(QWidget *parent = nullptr);

    void addNode(const QString& id, const QString& label, bool isNewFile = false);
    void addEdge(const QString& from, const QString& to);
    void highlightFunction(const QString& functionName);
    void addFunctionCallHierarchy(const QJsonObject& functionCalls);

private:
    QGraphicsScene* scene;
    QMap<std::string, GraphicalCFGNode*> nodes;

    void layoutNodes();
};

#endif // GRAPHWIDGET_H