#ifndef CUSTOM_GRAPH_VIEW_H
#define CUSTOM_GRAPH_VIEW_H

#include <QGraphicsView>
#include <QJsonObject>
#include <QGraphicsTextItem>

class CustomGraphView : public QGraphicsView {
    Q_OBJECT

public:
    explicit CustomGraphView(QWidget *parent = nullptr);

    void addNode(int id, const QString& label, bool isNewFile);
    void addFunctionCallHierarchy(const QJsonObject& functionCalls);
    void highlightFunction(const QString& searchText);
    void clear();

private:
    QGraphicsScene* m_scene;
    
    QGraphicsTextItem* createNodeItem(const QString& label, bool isNewFile);
};

#endif // CUSTOM_GRAPH_VIEW_H