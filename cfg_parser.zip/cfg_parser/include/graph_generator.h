#ifndef GRAPH_GENERATOR_H
#define GRAPH_GENERATOR_H

#include <set>
#include <utility>
#include <memory>
#include <string>
#include <vector>
#include <map>
#include <clang/AST/Stmt.h>
#include <clang/Analysis/CFG.h>
#include <clang/AST/Decl.h>
#include <nlohmann/json.hpp>

namespace GraphGenerator {

    using json = nlohmann::json;

    struct CFGNode {
        int id;
        std::string label;
        std::set<int> successors;
        std::vector<std::string> statements;
        
            // Default constructor
        CFGNode() : id(-1), label("") {}
            
        // Existing constructor
        CFGNode(int nodeId, const std::string& lbl = "")
            : id(nodeId), label(lbl) {}
    };
        
    struct CFGEdge {
        int sourceID;
        int targetID;
        bool isExceptionEdge;
        std::string label;
    };

    class CFGGraph {
    public:
        // Add these method declarations
        void writeToDotFile(const std::string& filename) const;
        void writeToJsonFile(const std::string& filename, const json& astJson, const json& functionCallJson);
        std::string getNodeLabel(int nodeID) const;

        // New methods for exception handling
        void addStatement(int nodeID, const std::string& stmt);
        void addExceptionEdge(int sourceID, int targetID);
        bool isExceptionEdge(int sourceID, int targetID) const;
        void markNodeAsTryBlock(int nodeID);
        void markNodeAsThrowingException(int nodeID);
        bool isNodeTryBlock(int nodeID) const;
        bool isNodeThrowingException(int nodeID) const;
        

        // Existing methods
        void addNode(int nodeID) {
            if (nodes.find(nodeID) == nodes.end()) {
                nodes[nodeID] = CFGNode(nodeID, "Block " + std::to_string(nodeID));
            }
        }
        
        void addStatementToNode(int nodeID, const std::string& stmt) {
            if (nodes.find(nodeID) == nodes.end()) {
                addNode(nodeID);
            }
            nodes[nodeID].statements.push_back(stmt);
        }       
        
        void addEdge(int fromID, int toID) {
            if (nodes.find(fromID) == nodes.end()) {
                addNode(fromID);
            }
            nodes[fromID].successors.insert(toID);
        }    
        
        const std::map<int, CFGNode>& getNodes() const noexcept { 
            return nodes; 
        }
        
        
    private:
        std::map<int, CFGNode> nodes;
        std::set<std::pair<int, int>> exceptionEdges;
        std::set<int> tryBlocks;
        std::set<int> throwingBlocks;
    };

std::unique_ptr<CFGGraph> generateCFG(const clang::FunctionDecl* FD);
std::unique_ptr<CFGGraph> generateCustomCFG(const clang::FunctionDecl* FD);
std::string getStmtString(const clang::Stmt* S);

}

#endif // GRAPH_GENERATOR_H