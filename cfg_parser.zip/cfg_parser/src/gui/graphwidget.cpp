#include "graphwidget.h"
#include "graphical_cfg_node.h"
#include "edge.h"
#include <QJsonObject>
#include <QJsonArray>

GraphWidget::GraphWidget(QWidget *parent) : QGraphicsView(parent) {
    scene = new QGraphicsScene(this);
    setScene(scene);
    setRenderHint(QPainter::Antialiasing);
    setDragMode(QGraphicsView::ScrollHandDrag);
}

void GraphWidget::addNode(const QString& id, const QString& label, bool isNewFile) {
    // Create a graphical representation of the node
    GraphicalCFGNode* graphNode = new GraphicalCFGNode(id, label, isNewFile);
    
    // Store the node with its unique ID
    nodes[id.toStdString()] = graphNode;
    
    // Add to scene
    scene->addItem(graphNode);
}

void GraphWidget::addEdge(const QString& from, const QString& to) {
    // Find the graphical nodes
    auto fromNode = nodes[from.toStdString()];
    auto toNode = nodes[to.toStdString()];
    
    if (fromNode && toNode) {
        // Create an edge between the nodes
        Edge* edge = new Edge(fromNode, toNode);
        
        // Add edge to scene
        scene->addItem(edge);
    }
}

void GraphWidget::highlightFunction(const QString& functionName) {
    // Reset all node colors
    for (auto it = nodes.begin(); it != nodes.end(); ++it) {
        it.value()->setColor(Qt::blue);
    }

    // Find and highlight nodes with the function name
    for (auto it = nodes.begin(); it != nodes.end(); ++it) {
        if (it.value()->getNodeLabel().contains(functionName, Qt::CaseInsensitive)) {
            it.value()->setColor(Qt::red);
        }
    }
}

void GraphWidget::addFunctionCallHierarchy(const QJsonObject& functionCalls) {
    // Clear existing scene
    scene->clear();
    nodes.clear();

    // Iterate through function calls and add nodes
    for (auto it = functionCalls.begin(); it != functionCalls.end(); ++it) {
        // Add the caller node
        addNode(it.key(), it.key());

        // Check if the value is an array of callees
        if (it.value().isArray()) {
            QJsonArray callees = it.value().toArray();
            
            // Add edges to each callee
            for (const auto& calleeJson : callees) {
                QString callee = calleeJson.toString();
                
                // Add callee node if not already exists
                if (!nodes.contains(callee.toStdString())) {
                    addNode(callee, callee);
                }
                
                // Add edge from caller to callee
                addEdge(it.key(), callee);
            }
        }
    }

    // Perform basic layout
    layoutNodes();
}

void GraphWidget::layoutNodes() {
    // Simple grid-based layout
    int x = 50, y = 50;
    const int H_SPACING = 150;
    const int V_SPACING = 100;

    for (auto it = nodes.begin(); it != nodes.end(); ++it) {
        it.value()->setPos(x, y);
        
        x += H_SPACING;
        if (x > 800) { // Wrap to next row
            x = 50;
            y += V_SPACING;
        }
    }

    // Adjust scene rect to fit all items
    scene->setSceneRect(scene->itemsBoundingRect());
}