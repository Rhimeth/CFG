#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "customgraphview.h"
#include <QFileDialog>
#include <QFile> 
#include <QIODevice>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    delete ui->graph;

    // Create an instance of CustomGraphView and place it in the layout
    graph = new CustomGraphView(this);
    ui->verticalLayout->insertWidget(3, graph);  // Insert at the correct position
}

MainWindow::~MainWindow() {
    delete ui;
}

bool MainWindow::checkIfNewFile(const QString& fileOrigin) {
    // Implement your logic to determine if a file is new
    // This is a placeholder implementation
    static QStringList seenFiles;
    if (!seenFiles.contains(fileOrigin)) {
        seenFiles.append(fileOrigin);
        return true;
    }
    return false;
}

void MainWindow::on_openFilesButton_clicked() {
    QStringList filenames = QFileDialog::getOpenFileNames(this, "Select Source Files", "", "C++ Files (*.cpp *.h)");
    if (filenames.isEmpty()) return;

    // Ensure these widgets exist in your .ui file
    ui->fileList->clear();
    for (const QString& file : filenames) {
        ui->fileList->addItem(file);
    }

    processFiles(filenames);
}

void MainWindow::processFiles(const QStringList& filenames) {
    for (const QString& filename : filenames) {
        loadGraphFromJson(filename);
    }
}

void MainWindow::loadGraphFromJson(const QString& filename) {
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) return;

    QByteArray jsonData = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    QJsonObject rootObj = doc.object();
    
    QJsonArray cfgBlocks = rootObj["cfg"].toArray();
    for (const QJsonValue& value : cfgBlocks) {
        QJsonObject node = value.toObject();
        int id = node["id"].toInt();
        QString label = node["label"].toString();
        QString fileOrigin = node["file"].toString();
        bool isNewFile = checkIfNewFile(fileOrigin);

        graph->addNode(id, label, isNewFile);
    }

    graph->addFunctionCallHierarchy(rootObj["function_calls"].toObject());
}

void MainWindow::on_searchButton_clicked() {
    QString searchText = ui->search->text();
    if (!searchText.isEmpty()) {
        graph->highlightFunction(searchText);
    }
}

void MainWindow::on_toggleFunctionGraph_clicked() {
    graph->clear();
    graph->addFunctionCallHierarchy(functionCallJson);
}