#include "customgraphview.h"
#include <QGraphicsTextItem>
#include <QJsonArray>
#include <QDebug>
#include <cmath>

CustomGraphView::CustomGraphView(QWidget *parent)
    : QGraphicsView(parent), m_scene(new QGraphicsScene(this)) {
    setScene(m_scene);
    setRenderHint(QPainter::Antialiasing);
}

QGraphicsTextItem* CustomGraphView::createNodeItem(const QString& label, bool isNewFile) {
    QGraphicsTextItem* nodeItem = m_scene->addText(label);
    
    // Optional: Color nodes differently based on isNewFile
    if (isNewFile) {
        nodeItem->setDefaultTextColor(Qt::blue);
    } else {
        nodeItem->setDefaultTextColor(Qt::black);
    }
    
    return nodeItem;
}

void CustomGraphView::addNode(int id, const QString& label, bool isNewFile) {
    qDebug() << "Adding node:" << id << label << isNewFile;
    
    QGraphicsTextItem* nodeItem = createNodeItem(label, isNewFile);
    
    // Simple positioning (you'll want more sophisticated positioning)
    nodeItem->setPos(id * 100, 0);
}

void CustomGraphView::addFunctionCallHierarchy(const QJsonObject& functionCalls) {
    qDebug() << "Adding function call hierarchy";
    
    // Clear existing scene
    m_scene->clear();
    
    // Iterate through function calls and add nodes
    for (auto it = functionCalls.begin(); it != functionCalls.end(); ++it) {
        addNode(it.key().toInt(), it.key(), true);
    }
}

void CustomGraphView::highlightFunction(const QString& searchText) {
    qDebug() << "Highlighting function:" << searchText;
    
    foreach (QGraphicsItem* item, m_scene->items()) {
        if (QGraphicsTextItem* textItem = dynamic_cast<QGraphicsTextItem*>(item)) {
            if (textItem->toPlainText().contains(searchText, Qt::CaseInsensitive)) {
                textItem->setDefaultTextColor(Qt::red);
            }
        }
    }
}

void CustomGraphView::clear() {
    qDebug() << "Clearing graph";
    m_scene->clear();
}