#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStringList>
#include <QJsonObject>
#include "customgraphview.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    
private slots:
    void on_openFilesButton_clicked();
    void on_searchButton_clicked();
    void on_toggleFunctionGraph_clicked();

private:
    bool checkIfNewFile(const QString& fileOrigin);
    void processFiles(const QStringList& filenames);
    void loadGraphFromJson(const QString& filename);

    Ui::MainWindow *ui;
    CustomGraphView* graph;
    QJsonObject functionCallJson;
};

#endif // MAINWINDOW_H